package misc

import (
	"math/big"
	"testing"

	"github.com/dominant-strategies/go-quai/common"
	"github.com/dominant-strategies/go-quai/core/types"
	"github.com/dominant-strategies/go-quai/params"
	"github.com/stretchr/testify/require"
)

func TestCalculateKQuai(t *testing.T) {

	// Term1: ParentExchangeRate
	// Term2: MinerDifficulty
	// Term3: Best Difficulty

	// Expectation is that if the best difficulty is higher, the kquai adjust higher
	// and if its lower, it adjust lower
	// Adjustment upwards doesnt seem to have a limit, but adjustment lower does
	testCases := [][4]int64{
		{1000, 10000000000000000, 5000, 999},
		{1000, 10000000000000000, 110000000000000000, 1009},
		{1000, 10000000000000000, 5000000000000000, 999},
		{10000000, 10000000000000000, 20000000000000000, 10009630},
		{1000, 10000000000000000, 1000000000000000000, 1087},
		{100000000, 100000, 1000000000000000000, 277777777877677772},
		{10000000000000, 10000000000000000, 10, 9990000000000},
	}

	for _, test := range testCases {
		newBeta0 := new(big.Int).Quo(new(big.Int).Mul(big.NewInt(test[2]), common.Big2e64), common.LogBig(big.NewInt(test[2])))
		// computation
		kQuai := CalculateKQuai(big.NewInt(test[0]), big.NewInt(test[1]), 10, newBeta0)
		require.Equal(t, test[3], kQuai.Int64())
	}

}

func TestCalculateKQuaiSlowdownAfterKQuaiChangeBlock(t *testing.T) {
	// Test the 3x slowdown mechanism for KQuai increases after KQuaiChangeBlock

	t.Run("KQuai increases are 3x slower after KQuaiChangeBlock", func(t *testing.T) {
		parentExchangeRate := big.NewInt(1000000)
		minerDifficulty := big.NewInt(10000000000000000)

		// Create a scenario that would cause KQuai to increase
		// Use high best difficulty to trigger increase
		bestDifficulty := big.NewInt(100000000000000000) // Much higher than miner difficulty
		newBeta0 := new(big.Int).Quo(new(big.Int).Mul(bestDifficulty, common.Big2e64), common.LogBig(bestDifficulty))

		// Test before KQuaiChangeBlock
		beforeBlock := params.KQuaiChangeBlock - 1
		kQuaiBefore := CalculateKQuai(parentExchangeRate, minerDifficulty, beforeBlock, newBeta0)
		increaseBefore := new(big.Int).Sub(kQuaiBefore, parentExchangeRate)

		// Test after KQuaiChangeBlock
		afterBlock := params.KQuaiChangeBlock + 1
		kQuaiAfter := CalculateKQuai(parentExchangeRate, minerDifficulty, afterBlock, newBeta0)
		increaseAfter := new(big.Int).Sub(kQuaiAfter, parentExchangeRate)

		// Only proceed if we actually have increases in both cases
		if increaseBefore.Cmp(common.Big0) <= 0 || increaseAfter.Cmp(common.Big0) <= 0 {
			t.Skip("Test scenario doesn't produce increases in both cases")
		}

		// The increase after should be approximately 3x smaller
		expectedIncreaseAfter := new(big.Int).Div(increaseBefore, big.NewInt(3))

		// Allow for some rounding tolerance (within 10% difference)
		tolerance := new(big.Int).Div(expectedIncreaseAfter, big.NewInt(10))
		diff := new(big.Int).Sub(increaseAfter, expectedIncreaseAfter)
		if diff.Cmp(common.Big0) < 0 {
			diff = new(big.Int).Neg(diff)
		}

		require.True(t, diff.Cmp(tolerance) <= 0,
			"Expected increase after KQuaiChangeBlock to be ~3x smaller. Before: %v, After: %v, Expected: %v",
			increaseBefore, increaseAfter, expectedIncreaseAfter)

		t.Logf("Before KQuaiChangeBlock - KQuai: %v, Increase: %v", kQuaiBefore, increaseBefore)
		t.Logf("After KQuaiChangeBlock - KQuai: %v, Increase: %v", kQuaiAfter, increaseAfter)
		t.Logf("Slowdown ratio: %v", new(big.Float).Quo(new(big.Float).SetInt(increaseBefore), new(big.Float).SetInt(increaseAfter)))
	})

	t.Run("KQuai decreases are NOT affected by slowdown", func(t *testing.T) {
		parentExchangeRate := big.NewInt(1000000)
		minerDifficulty := big.NewInt(10000000000000000)

		// Create a scenario that would cause KQuai to decrease
		// Use low best difficulty to trigger decrease
		bestDifficulty := big.NewInt(1000000000000000) // Much lower than miner difficulty
		newBeta0 := new(big.Int).Quo(new(big.Int).Mul(bestDifficulty, common.Big2e64), common.LogBig(bestDifficulty))

		// Test before KQuaiChangeBlock
		beforeBlock := params.KQuaiChangeBlock - 1
		kQuaiBefore := CalculateKQuai(parentExchangeRate, minerDifficulty, beforeBlock, newBeta0)
		decreaseBefore := new(big.Int).Sub(parentExchangeRate, kQuaiBefore)

		// Test after KQuaiChangeBlock
		afterBlock := params.KQuaiChangeBlock + 1
		kQuaiAfter := CalculateKQuai(parentExchangeRate, minerDifficulty, afterBlock, newBeta0)
		decreaseAfter := new(big.Int).Sub(parentExchangeRate, kQuaiAfter)

		// The decreases should be the same (no slowdown for decreases)
		require.Equal(t, decreaseBefore.Int64(), decreaseAfter.Int64(),
			"KQuai decreases should not be affected by slowdown mechanism")

		t.Logf("Before KQuaiChangeBlock - KQuai: %v, Decrease: %v", kQuaiBefore, decreaseBefore)
		t.Logf("After KQuaiChangeBlock - KQuai: %v, Decrease: %v", kQuaiAfter, decreaseAfter)
	})

	t.Run("Multiple scenarios to verify 3x slowdown magnitude", func(t *testing.T) {
		testCases := []struct {
			name               string
			parentExchangeRate int64
			minerDifficulty    int64
			bestDifficulty     int64
		}{
			{"Small values", 1000, 10000000000000000, 100000000000000000},
			{"Medium values", 100000, 50000000000000000, 500000000000000000},
			{"Large values", 10000000, 100000000000000000, 1000000000000000000},
		}

		for _, tc := range testCases {
			t.Run(tc.name, func(t *testing.T) {
				parentRate := big.NewInt(tc.parentExchangeRate)
				minerDiff := big.NewInt(tc.minerDifficulty)
				bestDiff := big.NewInt(tc.bestDifficulty)
				newBeta0 := new(big.Int).Quo(new(big.Int).Mul(bestDiff, common.Big2e64), common.LogBig(bestDiff))

				// Before KQuaiChangeBlock
				kQuaiBefore := CalculateKQuai(parentRate, minerDiff, params.KQuaiChangeBlock-1, newBeta0)
				increaseBefore := new(big.Int).Sub(kQuaiBefore, parentRate)

				// After KQuaiChangeBlock
				kQuaiAfter := CalculateKQuai(parentRate, minerDiff, params.KQuaiChangeBlock+1, newBeta0)
				increaseAfter := new(big.Int).Sub(kQuaiAfter, parentRate)

				// Only test if there's actually an increase (not a decrease)
				if increaseBefore.Cmp(common.Big0) > 0 && increaseAfter.Cmp(common.Big0) > 0 {
					// Calculate the actual slowdown ratio
					ratio := new(big.Float).Quo(new(big.Float).SetInt(increaseBefore), new(big.Float).SetInt(increaseAfter))
					ratioFloat, _ := ratio.Float64()

					// For very small values (single digits), the integer division can cause larger deviations
					tolerance := 1.0 // Very generous tolerance for small values
					if increaseBefore.Cmp(big.NewInt(10000)) > 0 {
						tolerance = 0.3 // 30% tolerance for larger values
					}

					minRatio := 3.0 - tolerance
					maxRatio := 3.0 + tolerance

					require.True(t, ratioFloat >= minRatio && ratioFloat <= maxRatio,
						"Slowdown ratio should be approximately 3x, got %.2f (expected %.2f-%.2f)", ratioFloat, minRatio, maxRatio)

					t.Logf("%s - Slowdown ratio: %.2f", tc.name, ratioFloat)
				}
			})
		}
	})

	t.Run("Edge case: exactly at KQuaiChangeBlock", func(t *testing.T) {
		parentExchangeRate := big.NewInt(1000000)
		minerDifficulty := big.NewInt(10000000000000000)
		bestDifficulty := big.NewInt(100000000000000000)
		newBeta0 := new(big.Int).Quo(new(big.Int).Mul(bestDifficulty, common.Big2e64), common.LogBig(bestDifficulty))

		// Test at exact KQuaiChangeBlock
		kQuaiAtChange := CalculateKQuai(parentExchangeRate, minerDifficulty, params.KQuaiChangeBlock, newBeta0)
		increaseAtChange := new(big.Int).Sub(kQuaiAtChange, parentExchangeRate)

		// Test one block after
		kQuaiAfterChange := CalculateKQuai(parentExchangeRate, minerDifficulty, params.KQuaiChangeBlock+1, newBeta0)
		increaseAfterChange := new(big.Int).Sub(kQuaiAfterChange, parentExchangeRate)

		// At KQuaiChangeBlock, slowdown should NOT be active yet
		// After KQuaiChangeBlock, slowdown SHOULD be active
		if increaseAtChange.Cmp(common.Big0) > 0 && increaseAfterChange.Cmp(common.Big0) > 0 {
			require.True(t, increaseAtChange.Cmp(increaseAfterChange) > 0,
				"Increase should be larger at KQuaiChangeBlock than after (when slowdown kicks in)")
		}

		t.Logf("At KQuaiChangeBlock: increase = %v", increaseAtChange)
		t.Logf("After KQuaiChangeBlock: increase = %v", increaseAfterChange)
	})
}

func TestKawpowEquivalentDifficulty(t *testing.T) {
	testCases := []struct {
		difficulty         *big.Int
		shaCount           *big.Int
		scryptCount        *big.Int
		expectedDifficulty *big.Int
	}{
		// If the sha and scrypt shares are zero, the equivalent difficulty doesnt change
		{big.NewInt(1000000), big.NewInt(0), big.NewInt(0), big.NewInt(1000000)},
		// If the sha and scrypt shares are over the expected shares, the equivalent should reach a ceil
		{big.NewInt(1000000), new(big.Int).Mul(big.NewInt(0), common.Big2e32), new(big.Int).Mul(big.NewInt(8), common.Big2e32), big.NewInt(9000000)},
		{big.NewInt(1000000), new(big.Int).Mul(big.NewInt(8), common.Big2e32), new(big.Int).Mul(big.NewInt(0), common.Big2e32), big.NewInt(9000000)},
		{big.NewInt(1000000), new(big.Int).Mul(big.NewInt(4), common.Big2e32), new(big.Int).Mul(big.NewInt(4), common.Big2e32), big.NewInt(9000000)},
		{big.NewInt(1000000), new(big.Int).Mul(big.NewInt(10), common.Big2e32), new(big.Int).Mul(big.NewInt(10), common.Big2e32), big.NewInt(9000000)},
		// If the sha and scrypt shares are half of the expected shares, the equivalent difficulty should be 1.8x
		{big.NewInt(1000000), new(big.Int).Mul(big.NewInt(2), common.Big2e32), new(big.Int).Mul(big.NewInt(2), common.Big2e32), big.NewInt(1800000)},
	}

	shaDiff := big.NewInt(10)
	scryptDiff := big.NewInt(20)

	for _, tc := range testCases {
		header := newRewardTestHeader(params.ShaEquivalentDifficultyForkBlock-1, 1, tc.difficulty, shaDiff, tc.shaCount, scryptDiff, tc.scryptCount)

		result := KawPowEquivalentDifficulty(header, tc.difficulty)
		require.Equal(t, tc.expectedDifficulty, result, "Expected %v got %v", tc.expectedDifficulty, result)
	}
}

func TestKawpowEquivalentDifficultyForkBoundaryAndFallback(t *testing.T) {
	difficulty := big.NewInt(9000000000000000)
	shaCount := new(big.Int).Set(params.TargetShaShares)
	scryptCount := new(big.Int).Mul(big.NewInt(2), common.Big2e32)
	shaDiff := calculateShaDiffForEquivalentDifficulty(difficulty, shaCount)
	scryptDiff := big.NewInt(20)

	preFork := newRewardTestHeader(params.ShaEquivalentDifficultyForkBlock-1, params.ShaEquivalentDifficultyForkBlock-1, difficulty, shaDiff, shaCount, scryptDiff, scryptCount)
	postFork := newRewardTestHeader(params.ShaEquivalentDifficultyForkBlock, params.ShaEquivalentDifficultyForkBlock, difficulty, shaDiff, shaCount, scryptDiff, scryptCount)

	require.Equal(t,
		KawPowEquivalentDifficulty(preFork, difficulty),
		ForkAwareKawPowEquivalentDifficulty(preFork, difficulty),
		"pre-fork dispatcher should use legacy equivalent difficulty",
	)
	require.Equal(t,
		ShaAnchoredEquivalentDifficulty(postFork),
		ForkAwareKawPowEquivalentDifficulty(postFork, difficulty),
		"post-fork dispatcher should use the SHA-anchored equivalent difficulty",
	)
}

func TestShaAnchoredEquivalentDifficultyBootstrapRegression(t *testing.T) {
	expectedDifficulty := big.NewInt(1234567890000000)
	shaCount := new(big.Int).Set(params.TargetShaShares)
	shaDiff := calculateShaDiffForEquivalentDifficulty(expectedDifficulty, shaCount)
	header := newRewardTestHeader(params.ShaEquivalentDifficultyForkBlock, params.ShaEquivalentDifficultyForkBlock, expectedDifficulty, shaDiff, shaCount, big.NewInt(0), common.Big0)

	require.Equal(t, expectedDifficulty, ShaAnchoredEquivalentDifficulty(header))
	require.Equal(t, expectedDifficulty, ForkAwareKawPowEquivalentDifficulty(header, expectedDifficulty))
}

func TestShaAnchoredEquivalentDifficultyValues(t *testing.T) {
	shaCount := new(big.Int).Set(params.TargetShaShares)
	scryptCount := new(big.Int).Mul(big.NewInt(2), common.Big2e32)

	testCases := []struct {
		name           string
		normalizedDiff *big.Int
		shaCount       *big.Int
		scryptCount    *big.Int
	}{
		{
			name:           "target SHA shares no scrypt",
			normalizedDiff: big.NewInt(4500000000000000),
			shaCount:       shaCount,
			scryptCount:    common.Big0,
		},
		{
			name:           "target SHA shares with scrypt shares",
			normalizedDiff: big.NewInt(4500000000000000),
			shaCount:       shaCount,
			scryptCount:    scryptCount,
		},
		{
			name:           "below reward floor clamps before share adjustment",
			normalizedDiff: big.NewInt(1),
			shaCount:       shaCount,
			scryptCount:    common.Big0,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			shaDiff := new(big.Int).Mul(tc.normalizedDiff, params.InitialShaDiffMultiple)
			header := newRewardTestHeader(params.ShaEquivalentDifficultyForkBlock, params.ShaEquivalentDifficultyForkBlock, tc.normalizedDiff, shaDiff, tc.shaCount, big.NewInt(0), tc.scryptCount)

			expectedNormalizedDiff := new(big.Int).Set(tc.normalizedDiff)
			minDiff := new(big.Int).Set(params.MinDifficultyForShaEquivalentDifficulty)
			if expectedNormalizedDiff.Cmp(minDiff) < 0 {
				expectedNormalizedDiff = minDiff
			}
			expected := KawPowEquivalentDifficulty(header, expectedNormalizedDiff)
			actual := ShaAnchoredEquivalentDifficulty(header)

			t.Logf("normalized SHA difficulty %v produced equivalent difficulty %v", expectedNormalizedDiff, actual)
			require.Equal(t, expected, actual)
		})
	}
}

func TestForkAwareKawPowEquivalentDifficultyWeakShaDoesNotPanic(t *testing.T) {
	difficulty := big.NewInt(9000000000000000)
	shaDiff := calculateShaDiffForEquivalentDifficulty(difficulty, params.TargetShaShares)
	scryptCount := new(big.Int).Mul(big.NewInt(2), common.Big2e32)

	testCases := []struct {
		name     string
		shaCount *big.Int
	}{
		{
			name:     "zero SHA shares",
			shaCount: common.Big0,
		},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			header := newRewardTestHeader(params.ShaEquivalentDifficultyForkBlock, params.ShaEquivalentDifficultyForkBlock, difficulty, shaDiff, tc.shaCount, big.NewInt(0), scryptCount)

			require.NotPanics(t, func() {
				require.Equal(t, ShaAnchoredEquivalentDifficulty(header), ForkAwareKawPowEquivalentDifficulty(header, difficulty))
			})
		})
	}
}

func TestRewardPathUsesShaAnchoredEquivalentDifficulty(t *testing.T) {
	blockNumber := params.ShaEquivalentDifficultyForkBlock
	headerDifficulty := big.NewInt(8000000000000000)
	shaCount := new(big.Int).Set(params.TargetShaShares)
	expectedEquivalent := big.NewInt(4500000000000000)
	shaDiff := calculateShaDiffForEquivalentDifficulty(expectedEquivalent, shaCount)
	exchangeRate := big.NewInt(221077819000000000)

	block := types.EmptyWorkObject(common.ZONE_CTX)
	header := block.WorkObjectHeader()
	header.SetPrimeTerminusNumber(new(big.Int).SetUint64(blockNumber))
	header.SetNumber(new(big.Int).SetUint64(blockNumber))
	header.SetDifficulty(headerDifficulty)
	header.SetShaDiffAndCount(types.NewPowShareDiffAndCount(shaDiff, shaCount, common.Big0))
	header.SetScryptDiffAndCount(types.NewPowShareDiffAndCount(big.NewInt(1), common.Big0, common.Big0))

	logDiff := common.LogBig(expectedEquivalent)
	logDiff = new(big.Int).Sub(logDiff, common.LogBig(new(big.Int).SetUint64(params.KQuaiDifficultyDivisor)))
	expectedQuaiReward := new(big.Int).Quo(new(big.Int).Mul(exchangeRate, logDiff), common.Big2e64)
	if expectedQuaiReward.Cmp(common.Big0) == 0 {
		expectedQuaiReward = big.NewInt(1)
	}

	expectedQiReward := new(big.Int).Quo(expectedEquivalent, params.OneOverKqi(header.NumberU64()))
	if expectedQiReward.Cmp(common.Big0) == 0 {
		expectedQiReward = big.NewInt(1)
	}

	require.Equal(t, expectedEquivalent, ForkAwareKawPowEquivalentDifficulty(header, headerDifficulty))
	require.Equal(t, expectedQuaiReward, CalculateQuaiReward(header, headerDifficulty, exchangeRate))
	require.Equal(t, expectedQiReward, CalculateQiReward(header, headerDifficulty))

	qiAmt := big.NewInt(7)
	quaiAmt := big.NewInt(13)
	expectedQiToQuai := new(big.Int).Quo(new(big.Int).Mul(expectedQuaiReward, qiAmt), expectedQiReward)
	expectedQuaiToQi := new(big.Int).Quo(new(big.Int).Mul(expectedQiReward, quaiAmt), expectedQuaiReward)

	require.Equal(t, expectedQiToQuai, QiToQuai(block, exchangeRate, headerDifficulty, qiAmt))
	require.Equal(t, expectedQuaiToQi, QuaiToQi(block, exchangeRate, headerDifficulty, quaiAmt))
}

func TestPostForkWorkShareRewardBases(t *testing.T) {
	block := newPostForkRewardTestBlock(params.ConversionLockChangeForkBlock)
	exchangeRate := big.NewInt(221077819000000000)
	block.Header().SetAvgTxFees(big.NewInt(101))
	block.Header().SetTotalFees(big.NewInt(200))

	divisor := big.NewInt(int64(params.ExpectedWorksharesPerBlock + 1))
	expectedQuaiPool := new(big.Int).Add(
		CalculateQuaiReward(block.WorkObjectHeader(), block.Difficulty(), exchangeRate),
		big.NewInt(202),
	)
	expectedQuaiShare := new(big.Int).Div(expectedQuaiPool, divisor)
	expectedQiShare := new(big.Int).Div(
		CalculateQiReward(block.WorkObjectHeader(), block.Difficulty()),
		divisor,
	)

	require.Equal(t, expectedQuaiPool, CalculateQuaiRewardWithFees(block, exchangeRate, block.Difficulty()))
	require.Equal(t, expectedQuaiShare, CalculateWorkShareRewardBase(block, exchangeRate, false))
	require.Equal(t, expectedQiShare, CalculateWorkShareRewardBase(block, exchangeRate, true))

	// Qi rewards are proportional to hash and independent of the Quai fee pool.
	block.Header().SetAvgTxFees(big.NewInt(1000000))
	block.Header().SetTotalFees(big.NewInt(2000000))
	require.Equal(t, expectedQiShare, CalculateWorkShareRewardBase(block, exchangeRate, true))
	require.NotEqual(t, expectedQuaiShare, CalculateWorkShareRewardBase(block, exchangeRate, false))
}

func TestQuaiRewardPoolPreservesPreForkFees(t *testing.T) {
	block := newPostForkRewardTestBlock(params.ConversionLockChangeForkBlock - 1)
	exchangeRate := big.NewInt(221077819000000000)
	block.Header().SetAvgTxFees(big.NewInt(101))
	block.Header().SetTotalFees(big.NewInt(200))

	expected := CalculateQuaiReward(block.WorkObjectHeader(), block.Difficulty(), exchangeRate)
	expected.Add(expected, big.NewInt(201))
	require.Equal(t, expected, CalculateQuaiRewardPool(block, exchangeRate, block.Difficulty()))
}

func TestConversionRewardAddsFeesOnlyAfterFork(t *testing.T) {
	exchangeRate := big.NewInt(221077819000000000)
	fees := big.NewInt(202)

	testBlock := func(primeHeight uint64) *types.WorkObject {
		block := newPostForkRewardTestBlock(primeHeight)
		block.Header().SetAvgTxFees(big.NewInt(101))
		block.Header().SetTotalFees(big.NewInt(200))
		return block
	}

	preFork := testBlock(params.ConversionLockChangeForkBlock - 1)
	preForkBase := CalculateQuaiReward(preFork.WorkObjectHeader(), preFork.Difficulty(), exchangeRate)
	require.Equal(t, preForkBase, CalculateQuaiConversionReward(preFork, exchangeRate, preFork.Difficulty()))

	postFork := testBlock(params.ConversionLockChangeForkBlock)
	postForkBase := CalculateQuaiReward(postFork.WorkObjectHeader(), postFork.Difficulty(), exchangeRate)
	postForkWithFees := new(big.Int).Add(new(big.Int).Set(postForkBase), fees)
	require.Equal(t, postForkWithFees, CalculateQuaiConversionReward(postFork, exchangeRate, postFork.Difficulty()))

	// The canonical helpers use the corrected conversion basis in both
	// directions.
	qiReward := CalculateQiReward(postFork.WorkObjectHeader(), postFork.Difficulty())
	require.Equal(t, postForkWithFees, QiToQuai(postFork, exchangeRate, postFork.Difficulty(), qiReward))
	require.Equal(t, qiReward, QuaiToQi(postFork, exchangeRate, postFork.Difficulty(), postForkWithFees))
}

func TestCapFeeFeedbackSignal(t *testing.T) {
	originalCap := params.FeeFeedbackMaxRewardMultipleBasisPoints
	params.FeeFeedbackMaxRewardMultipleBasisPoints = 40000
	defer func() { params.FeeFeedbackMaxRewardMultipleBasisPoints = originalCap }()

	feeFreeReward := big.NewInt(100)
	expectedCap := big.NewInt(400)

	require.Equal(t, expectedCap, CapFeeFeedbackSignal(feeFreeReward, big.NewInt(2_000)))
	require.Equal(t, common.Big1, CapFeeFeedbackSignal(feeFreeReward, common.Big1))
}

func TestFeeFeedbackCapBoundsSustainedFeesAtFourTimesReward(t *testing.T) {
	originalCap := params.FeeFeedbackMaxRewardMultipleBasisPoints
	params.FeeFeedbackMaxRewardMultipleBasisPoints = 40000
	defer func() { params.FeeFeedbackMaxRewardMultipleBasisPoints = originalCap }()

	exchangeRate := big.NewInt(221077819000000000)
	block := newPostForkRewardTestBlock(params.ConversionLockChangeForkBlock)
	feeFreeReward := CalculateQuaiReward(block.WorkObjectHeader(), block.Difficulty(), exchangeRate)
	extremeFees := new(big.Int).Mul(new(big.Int).Set(feeFreeReward), big.NewInt(20))
	maximumPricingReward := new(big.Int).Mul(new(big.Int).Set(feeFreeReward), big.NewInt(5))
	averageFees := new(big.Int)

	for range 1000 {
		block.Header().SetAvgTxFees(averageFees)
		cappedFees := CapFeeFeedbackSignal(feeFreeReward, extremeFees)
		expectedCap := new(big.Int).Mul(new(big.Int).Set(feeFreeReward), big.NewInt(4))

		require.Equal(t, expectedCap, cappedFees)

		// A[n+1] = (99*A[n] + cappedFees/2) / 100.
		halfCappedFees := new(big.Int).Div(cappedFees, common.Big2)
		averageFees = new(big.Int).Div(
			new(big.Int).Add(new(big.Int).Mul(averageFees, big.NewInt(99)), halfCappedFees),
			big.NewInt(100),
		)
	}

	block.Header().SetAvgTxFees(averageFees)
	finalPricingReward := CalculateQuaiConversionReward(block, exchangeRate, block.Difficulty())
	require.LessOrEqual(t, finalPricingReward.Cmp(maximumPricingReward), 0)
	distanceFromBound := new(big.Int).Sub(maximumPricingReward, finalPricingReward)
	require.Less(t, distanceFromBound.Cmp(new(big.Int).Div(maximumPricingReward, big.NewInt(1000))), 0)
}

func newPostForkRewardTestBlock(primeHeight uint64) *types.WorkObject {
	headerDifficulty := big.NewInt(8000000000000000)
	shaCount := new(big.Int).Set(params.TargetShaShares)
	shaDiff := calculateShaDiffForEquivalentDifficulty(big.NewInt(4500000000000000), shaCount)

	block := types.EmptyWorkObject(common.ZONE_CTX)
	header := block.WorkObjectHeader()
	header.SetPrimeTerminusNumber(new(big.Int).SetUint64(primeHeight))
	header.SetNumber(new(big.Int).SetUint64(primeHeight))
	header.SetDifficulty(headerDifficulty)
	header.SetShaDiffAndCount(types.NewPowShareDiffAndCount(shaDiff, shaCount, common.Big0))
	header.SetScryptDiffAndCount(types.NewPowShareDiffAndCount(big.NewInt(1), common.Big0, common.Big0))
	return block
}

func newRewardTestHeader(primeTerminus, blockNumber uint64, difficulty, shaDiff, shaCount, scryptDiff, scryptCount *big.Int) *types.WorkObjectHeader {
	workObject := types.EmptyWorkObject(common.ZONE_CTX)
	header := workObject.WorkObjectHeader()
	header.SetPrimeTerminusNumber(new(big.Int).SetUint64(primeTerminus))
	header.SetNumber(new(big.Int).SetUint64(blockNumber))
	header.SetDifficulty(new(big.Int).Set(difficulty))
	header.SetShaDiffAndCount(types.NewPowShareDiffAndCount(shaDiff, shaCount, common.Big0))
	header.SetScryptDiffAndCount(types.NewPowShareDiffAndCount(scryptDiff, scryptCount, common.Big0))
	return header
}

func calculateShaDiffForEquivalentDifficulty(equivalentDifficulty, shaCount *big.Int) *big.Int {
	expectedTotalShares := new(big.Int).Mul(big.NewInt(int64(params.ExpectedWorksharesPerBlock+1)), common.Big2e32)
	denominator := new(big.Int).Sub(expectedTotalShares, shaCount)
	normalizedDifficulty := new(big.Int).Div(new(big.Int).Mul(equivalentDifficulty, denominator), expectedTotalShares)

	return new(big.Int).Mul(normalizedDifficulty, params.InitialShaDiffMultiple)
}
