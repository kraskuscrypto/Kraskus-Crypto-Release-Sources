package types

import (
	"bytes"
	"fmt"
	"math/big"
	"testing"

	"github.com/dominant-strategies/go-quai/common"
	"github.com/dominant-strategies/go-quai/log"
	"github.com/dominant-strategies/go-quai/params"
	"github.com/stretchr/testify/require"
	"google.golang.org/protobuf/proto"
	"lukechampine.com/blake3"
)

var locations = []common.Location{
	{0, 0},
	{0, 1},
	{0, 2},
	{0, 3},
	{1, 0},
	{1, 1},
	{1, 2},
	{1, 3},
	{2, 0},
	{2, 1},
	{2, 2},
	{2, 3},
	{3, 0},
	{3, 1},
	{3, 2},
	{3, 3},
}

func woTestData() (*WorkObject, common.Hash) {
	wo := &WorkObject{}
	wo.SetWorkObjectHeader(&WorkObjectHeader{})
	wo.woHeader.SetHeaderHash(EmptyHeader().Hash())
	wo.woHeader.SetParentHash(EmptyHeader().Hash())
	wo.woHeader.SetNumber(big.NewInt(1))
	wo.woHeader.SetDifficulty(big.NewInt(123456789))
	wo.woHeader.SetPrimeTerminusNumber(big.NewInt(42))
	wo.woHeader.SetTxHash(common.HexToHash("0x456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef3"))
	wo.woHeader.SetLocation(common.Location{0, 0})
	wo.woHeader.SetMixHash(common.HexToHash("0x56789abcdef0123456789abcdef0123456789abcdef0123456789abcdef4"))
	wo.woHeader.SetPrimaryCoinbase(common.HexToAddress("0x123456789abcdef0123456789abcdef0123456789", common.Location{0, 0}))
	wo.woHeader.SetTime(uint64(1))
	wo.woHeader.SetNonce(EncodeNonce(uint64(1)))
	wo.woHeader.SetLock(0)
	wo.woHeader.SetData([]byte{0, 1, 2, 3})
	wo.woBody = EmptyWorkObjectBody()
	return wo, wo.Hash()
}

func powDiffAndCountTestData() *PowShareDiffAndCount {
	return NewPowShareDiffAndCount(
		big.NewInt(123456789),
		big.NewInt(42),
		big.NewInt(43),
	)
}

func woTestDataWithAuxPow() (*WorkObject, common.Hash) {
	wo, _ := woTestData()
	wo.WorkObjectHeader().SetPrimeTerminusNumber(big.NewInt(int64(params.KawPowForkBlock) + 1))
	wo.WorkObjectHeader().SetAuxPow(testAuxPow())
	wo.WorkObjectHeader().SetScryptDiffAndCount(powDiffAndCountTestData())
	wo.WorkObjectHeader().SetShaDiffAndCount(powDiffAndCountTestData())
	wo.WorkObjectHeader().SetShaShareTarget(big.NewInt(1000))
	wo.WorkObjectHeader().SetScryptShareTarget(big.NewInt(1000))
	wo.WorkObjectHeader().SetKawpowDifficulty(big.NewInt(10000))
	return wo, wo.Hash()
}

var (
	expectedWoHash         = common.HexToHash("0x7500ff0d2f7b060cfe252f214ea43abb96cd7182dad2ef8f0f5864bab1f3e70e")
	expectedUncleHash      = common.HexToHash("0x1dcc4de8dec75d7aab85b567b6ccd41ad312451b948a7413f0a142fd40d49347")
	expectedPETXProtoBytes = []byte{0xa, 0xc6, 0x1, 0xa, 0x22, 0xa, 0x20, 0x2d, 0x34, 0xee, 0x6, 0x9c, 0xf5, 0x9d, 0xcc, 0xec, 0x9d, 0x32, 0x56, 0x41, 0xf0,
		0xd8, 0x9, 0x21, 0x54, 0x40, 0xf9, 0xfb, 0xb, 0x64, 0x9d, 0x8c, 0x9d, 0x68, 0xdc, 0x55, 0xb4, 0xda, 0x71, 0x12, 0x22, 0xa, 0x20, 0x2d, 0x34, 0xee,
		0x6, 0x9c, 0xf5, 0x9d, 0xcc, 0xec, 0x9d, 0x32, 0x56, 0x41, 0xf0, 0xd8, 0x9, 0x21, 0x54, 0x40, 0xf9, 0xfb, 0xb, 0x64, 0x9d, 0x8c, 0x9d, 0x68, 0xdc,
		0x55, 0xb4, 0xda, 0x71, 0x1a, 0x1, 0x1, 0x22, 0x4, 0x7, 0x5b, 0xcd, 0x15, 0x2a, 0x22, 0xa, 0x20, 0x0, 0x4, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12,
		0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf3, 0x30, 0x1,
		0x3a, 0x4, 0xa, 0x2, 0x0, 0x0, 0x42, 0x22, 0xa, 0x20, 0x0, 0x0, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0,
		0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf4, 0x48, 0x1, 0x52, 0x1, 0x2a, 0x58, 0x0, 0x62, 0x16,
		0xa, 0x14, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0x1, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0x1, 0x23, 0x45, 0x67, 0x89, 0x6a, 0x4, 0x0,
		0x1, 0x2, 0x3, 0x12, 0xd9, 0x5, 0xa, 0xd6, 0x5, 0xa, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92,
		0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0xa, 0x22, 0xa, 0x20, 0x56, 0xe8,
		0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f,
		0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x12, 0x22, 0xa, 0x20, 0x1d, 0xcc, 0x4d, 0xe8, 0xde, 0xc7, 0x5d, 0x7a, 0xab, 0x85, 0xb5, 0x67, 0xb6, 0xcc, 0xd4, 0x1a,
		0xd3, 0x12, 0x45, 0x1b, 0x94, 0x8a, 0x74, 0x13, 0xf0, 0xa1, 0x42, 0xfd, 0x40, 0xd4, 0x93, 0x47, 0x1a, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b,
		0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63,
		0xb4, 0x21, 0x22, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0,
		0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x2a, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6,
		0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x32,
		0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c,
		0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x3a, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45,
		0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x3a, 0x22, 0xa, 0x20,
		0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1,
		0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x3a, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0,
		0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x42, 0x22, 0xa, 0x20, 0x0, 0x0, 0x0, 0x0,
		0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x52, 0x0,
		0x52, 0x0, 0x52, 0x0, 0x5a, 0x0, 0x5a, 0x0, 0x5a, 0x0, 0x62, 0x0, 0x62, 0x0, 0x62, 0x0, 0x6a, 0x0, 0x72, 0x0, 0x72, 0x0, 0x78, 0x0, 0x80, 0x1, 0x0, 0x8a,
		0x1, 0x0, 0x9a, 0x1, 0x0, 0xb2, 0x1, 0x22, 0xa, 0x20, 0x54, 0x4e, 0xb3, 0x14, 0x2c, 0x0, 0xf, 0xa, 0xd2, 0xc7, 0x6a, 0xc4, 0x1f, 0x42, 0x22, 0xab, 0xba,
		0xba, 0xbe, 0xd8, 0x30, 0xee, 0xaf, 0xee, 0x4b, 0x6d, 0xc5, 0x6b, 0x52, 0xd5, 0xca, 0xc0, 0xba, 0x1, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc,
		0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21,
		0xc0, 0x1, 0x0, 0xc8, 0x1, 0x0, 0xd0, 0x1, 0x0, 0xda, 0x1, 0x22, 0xa, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
		0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xe2, 0x1, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6,
		0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0xea, 0x1, 0x22,
		0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1,
		0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0xf0, 0x1, 0x0, 0xf8, 0x1, 0x0, 0x82, 0x2, 0x0, 0x8a, 0x2, 0x0, 0x9a, 0x2, 0x0, 0xa2, 0x2, 0x0, 0xaa, 0x2, 0x0, 0xb2,
		0x2, 0x0, 0xba, 0x2, 0x0, 0xc2, 0x2, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48,
		0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0xca, 0x2, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff,
		0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21}

	expectedBlockProtoBytes = []byte{0xa, 0xc6, 0x1, 0xa, 0x22, 0xa, 0x20, 0x2d, 0x34, 0xee, 0x6, 0x9c, 0xf5, 0x9d, 0xcc, 0xec, 0x9d, 0x32, 0x56, 0x41, 0xf0, 0xd8, 0x9,
		0x21, 0x54, 0x40, 0xf9, 0xfb, 0xb, 0x64, 0x9d, 0x8c, 0x9d, 0x68, 0xdc, 0x55, 0xb4, 0xda, 0x71, 0x12, 0x22, 0xa, 0x20, 0x2d, 0x34, 0xee, 0x6, 0x9c, 0xf5, 0x9d,
		0xcc, 0xec, 0x9d, 0x32, 0x56, 0x41, 0xf0, 0xd8, 0x9, 0x21, 0x54, 0x40, 0xf9, 0xfb, 0xb, 0x64, 0x9d, 0x8c, 0x9d, 0x68, 0xdc, 0x55, 0xb4, 0xda, 0x71, 0x1a, 0x1,
		0x1, 0x22, 0x4, 0x7, 0x5b, 0xcd, 0x15, 0x2a, 0x22, 0xa, 0x20, 0x0, 0x4, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12,
		0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf3, 0x30, 0x1, 0x3a, 0x4, 0xa, 0x2, 0x0, 0x0, 0x42, 0x22, 0xa, 0x20, 0x0,
		0x0, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78, 0x9a, 0xbc, 0xde, 0xf0, 0x12, 0x34, 0x56, 0x78,
		0x9a, 0xbc, 0xde, 0xf4, 0x48, 0x1, 0x52, 0x1, 0x2a, 0x58, 0x0, 0x62, 0x16, 0xa, 0x14, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0x1, 0x23, 0x45, 0x67, 0x89, 0xab,
		0xcd, 0xef, 0x1, 0x23, 0x45, 0x67, 0x89, 0x6a, 0x4, 0x0, 0x1, 0x2, 0x3, 0x12, 0xe3, 0x5, 0xa, 0xd6, 0x5, 0xa, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc,
		0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0xa, 0x22,
		0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62,
		0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x12, 0x22, 0xa, 0x20, 0x1d, 0xcc, 0x4d, 0xe8, 0xde, 0xc7, 0x5d, 0x7a, 0xab, 0x85, 0xb5, 0x67, 0xb6, 0xcc, 0xd4, 0x1a, 0xd3, 0x12,
		0x45, 0x1b, 0x94, 0x8a, 0x74, 0x13, 0xf0, 0xa1, 0x42, 0xfd, 0x40, 0xd4, 0x93, 0x47, 0x1a, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83,
		0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x22, 0x22, 0xa, 0x20, 0x56, 0xe8,
		0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63,
		0xb4, 0x21, 0x2a, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c,
		0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x32, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0,
		0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x3a, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc,
		0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x3a, 0x22,
		0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62,
		0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x3a, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48,
		0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x42, 0x22, 0xa, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
		0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x52, 0x0, 0x52, 0x0, 0x52, 0x0, 0x5a, 0x0, 0x5a, 0x0, 0x5a, 0x0,
		0x62, 0x0, 0x62, 0x0, 0x62, 0x0, 0x6a, 0x0, 0x72, 0x0, 0x72, 0x0, 0x78, 0x0, 0x80, 0x1, 0x0, 0x8a, 0x1, 0x0, 0x9a, 0x1, 0x0, 0xb2, 0x1, 0x22, 0xa, 0x20, 0x54, 0x4e,
		0xb3, 0x14, 0x2c, 0x0, 0xf, 0xa, 0xd2, 0xc7, 0x6a, 0xc4, 0x1f, 0x42, 0x22, 0xab, 0xba, 0xba, 0xbe, 0xd8, 0x30, 0xee, 0xaf, 0xee, 0x4b, 0x6d, 0xc5, 0x6b, 0x52, 0xd5,
		0xca, 0xc0, 0xba, 0x1, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99,
		0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0xc0, 0x1, 0x0, 0xc8, 0x1, 0x0, 0xd0, 0x1, 0x0, 0xda, 0x1, 0x22, 0xa, 0x20, 0x0, 0x0, 0x0, 0x0, 0x0,
		0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xe2, 0x1, 0x22, 0xa, 0x20, 0x56,
		0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3,
		0x63, 0xb4, 0x21, 0xea, 0x1, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99,
		0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0xf0, 0x1, 0x0, 0xf8, 0x1, 0x0, 0x82, 0x2, 0x0, 0x8a, 0x2, 0x0, 0x9a, 0x2, 0x0, 0xa2, 0x2, 0x0, 0xaa, 0x2,
		0x0, 0xb2, 0x2, 0x0, 0xba, 0x2, 0x0, 0xc2, 0x2, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83, 0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48,
		0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0xca, 0x2, 0x22, 0xa, 0x20, 0x56, 0xe8, 0x1f, 0x17, 0x1b, 0xcc, 0x55, 0xa6, 0xff, 0x83,
		0x45, 0xe6, 0x92, 0xc0, 0xf8, 0x6e, 0x5b, 0x48, 0xe0, 0x1b, 0x99, 0x6c, 0xad, 0xc0, 0x1, 0x62, 0x2f, 0xb5, 0xe3, 0x63, 0xb4, 0x21, 0x12, 0x0, 0x1a, 0x0, 0x22, 0x0, 0x2a, 0x0, 0x32, 0x0}
)

func TestWoHash(t *testing.T) {
	_, actualHash := woTestData()
	require.Equal(t, expectedWoHash, actualHash, "Hash not equal to expected hash")
}

func TestWoSealHash(t *testing.T) {
	testWo, _ := woTestData()
	actualHash := testWo.SealHash()
	expectedHash := common.HexToHash("0x7919e42c0222d548352b0e955e2e8a35b5e0ce59972e5f1a834e250f004d7c29")
	require.Equal(t, expectedHash, actualHash, "Seal hash not equal to expected hash")
}

func FuzzHeaderHash(f *testing.F) {
	fuzzHash(f,
		func(woh *WorkObjectHeader) common.Hash { return woh.headerHash },
		func(woh *WorkObjectHeader, hash common.Hash) { woh.headerHash = hash })
}

func FuzzParentHash(f *testing.F) {
	fuzzHash(f,
		func(woh *WorkObjectHeader) common.Hash { return woh.parentHash },
		func(woh *WorkObjectHeader, hash common.Hash) { woh.parentHash = hash })
}

func FuzzDifficultyHash(f *testing.F) {
	fuzzBigInt(f,
		func(woh *WorkObjectHeader) *big.Int { return woh.difficulty },
		func(woh *WorkObjectHeader, val *big.Int) { woh.difficulty = val })
}

func FuzzNumberHash(f *testing.F) {
	fuzzBigInt(f,
		func(woh *WorkObjectHeader) *big.Int { return woh.number },
		func(woh *WorkObjectHeader, val *big.Int) { woh.number = val })
}

func FuzzTxHash(f *testing.F) {
	fuzzHash(f,
		func(woh *WorkObjectHeader) common.Hash { return woh.TxHash() },
		func(woh *WorkObjectHeader, hash common.Hash) { woh.SetTxHash(hash) })
}

func FuzzMixHash(f *testing.F) {
	fuzzHash(f,
		func(woh *WorkObjectHeader) common.Hash { return woh.MixHash() },
		func(woh *WorkObjectHeader, hash common.Hash) { woh.SetMixHash(hash) })
}

func TestLocationHash(t *testing.T) {
	wo, hash := woTestData()

	for _, loc := range locations[1:] {
		woCopy := *wo
		woCopy.woHeader.location = loc
		require.NotEqual(t, woCopy.Hash(), hash, "Hash equal for location \noriginal: %v, modified: %v", wo.woHeader.location, loc)
	}
}

func FuzzTimeHash(f *testing.F) {
	fuzzUint64Field(f,
		func(woh *WorkObjectHeader) uint64 { return woh.time },
		func(woh *WorkObjectHeader, time uint64) { woh.time = time })
}

func FuzzNonceHash(f *testing.F) {
	fuzzUint64Field(f,
		func(woh *WorkObjectHeader) uint64 { return woh.nonce.Uint64() },
		func(woh *WorkObjectHeader, nonce uint64) { woh.nonce = EncodeNonce(nonce) })
}

func TestCalcUncleHash(t *testing.T) {
	tests := []struct {
		uncleNum          int
		expectedUncleHash common.Hash
		expectedWoHash    common.Hash
		shouldPass        bool
	}{
		{
			uncleNum:          0,
			expectedUncleHash: expectedUncleHash,
			expectedWoHash:    expectedWoHash,
			shouldPass:        true,
		},
		{
			uncleNum:          1,
			expectedUncleHash: expectedUncleHash,
			expectedWoHash:    expectedWoHash,
			shouldPass:        false,
		},
		{
			uncleNum:          5,
			expectedUncleHash: common.HexToHash("0x77e6cd2bc4107c87fad0b8af503c0ca12afb917c45dcf692692b28008c24a32d"),
			expectedWoHash:    common.HexToHash("0xdc58303f7db0241f619f9afbcd457933ba1da865e218f90435c1d8d8a3818574"),
			shouldPass:        true,
		},
	}

	// Run test cases
	for _, tt := range tests {
		t.Run(fmt.Sprintf("uncleNum=%d", tt.uncleNum), func(t *testing.T) {
			assertUncleHash(t, tt.uncleNum, tt.expectedUncleHash, tt.expectedWoHash, tt.shouldPass)
		})
	}
}

func TestProtoEncode(t *testing.T) {
	// Test data
	testWo, _ := woTestData()

	// Define test cases
	tests := []struct {
		name          string
		objectType    WorkObjectView
		expectedBytes []byte
	}{
		{
			name:          "PEtxObject",
			objectType:    PEtxObject,
			expectedBytes: expectedPETXProtoBytes,
		},
		{
			name:          "BlockObject",
			objectType:    BlockObject,
			expectedBytes: expectedBlockProtoBytes,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// ProtoEncode the test WorkObject
			protoTestWo, err := testWo.ProtoEncode(tt.objectType)
			require.NoError(t, err)

			// Marshal to bytes
			protoTestWoBytes, err := proto.Marshal(protoTestWo)
			require.NoError(t, err)

			// Compare with expected bytes
			require.Equal(t, tt.expectedBytes, protoTestWoBytes)
		})
	}
}

func TestProtoDecode(t *testing.T) {
	_, testWoHash := woTestData()

	tests := []struct {
		name         string
		objectType   WorkObjectView
		testBytes    []byte
		expectedHash common.Hash
	}{
		{
			"PETX",
			PEtxObject,
			expectedPETXProtoBytes,
			testWoHash,
		},
		{
			"BlockObject",
			BlockObject,
			expectedBlockProtoBytes,
			testWoHash,
		},
		{
			"WorkShareObject",
			WorkShareObject,
			expectedBlockProtoBytes,
			testWoHash,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			protoWo := &ProtoWorkObject{}
			err := proto.Unmarshal(tt.testBytes, protoWo)
			require.NoError(t, err)

			decoded := &WorkObject{}
			decoded.ProtoDecode(protoWo, common.Location{0, 0}, tt.objectType)
			require.Equal(t, decoded.Hash(), tt.expectedHash)
		})
	}
}

func TestWorkObjectHeaderProtoDecodeRejectsMissingMixHash(t *testing.T) {
	wo, _ := woTestData()
	protoHeader, err := wo.WorkObjectHeader().ProtoEncode()
	require.NoError(t, err)
	protoHeader.MixHash = nil

	var decoded WorkObjectHeader
	require.Error(t, decoded.ProtoDecode(protoHeader, common.Location{0, 0}))
}

func TestWorkObjectProtoDecodePEtxRejectsMissingBodyHeader(t *testing.T) {
	wo, _ := woTestData()
	protoWo, err := wo.ProtoEncode(PEtxObject)
	require.NoError(t, err)
	protoWo.WoBody.Header = nil

	var decoded WorkObject
	require.Error(t, decoded.ProtoDecode(protoWo, common.Location{0, 0}, PEtxObject))
}

func TestWorkObjectBodyProtoDecodeRejectsMissingBody(t *testing.T) {
	var decoded WorkObjectBody
	require.Error(t, decoded.ProtoDecode(nil, common.Location{0, 0}, BlockObject))
	require.Error(t, decoded.ProtoDecodeHeader(nil, common.Location{0, 0}))
}

func TestCopyWorkObject(t *testing.T) {
	originalWo, expectedHash := woTestData()

	newWo := CopyWorkObject(originalWo)

	require.Equal(t, expectedHash, newWo.Hash(), "Copied work object is different from new work object")

	// Test to make sure the copy doesn't modify original.
	newWo.WorkObjectHeader().SetLocation(common.Location{2, 2})
	require.NotEqual(t, expectedHash, newWo.Hash(), "WorkObject hash didn't change with a new location")
	require.Equal(t, originalWo.Hash(), expectedHash, "Copied WorkObject changed values from the original")
}

func TestNewWorkObject(t *testing.T) {
	// Verify that copy is same as original.
	originalWo, expectedHash := woTestData()
	newWo := NewWorkObject(originalWo.WorkObjectHeader(), originalWo.Body(), originalWo.Tx())

	require.Equal(t, expectedHash, newWo.Hash(), "NewWorkObject created a different WorkObject than the original")
}

func assertUncleHash(t *testing.T, uncleNum int, expectedUncleHash common.Hash, expectedWoHash common.Hash, shouldPass bool) {
	wo, _ := woTestData()
	wo.Body().uncles = make([]*WorkObjectHeader, uncleNum)
	for i := 0; i < uncleNum; i++ {
		uncle, _ := woTestData()
		wo.Body().uncles[i] = CopyWorkObjectHeader(uncle.WorkObjectHeader())
	}

	wo.Body().Header().SetUncleHash(CalcUncleHash(wo.Body().uncles))
	wo.woHeader.SetHeaderHash(wo.Body().header.Hash())

	if shouldPass {
		require.Equal(t, expectedUncleHash, wo.Header().UncleHash(), "Uncle hashes do not create the expected root hash")
		require.Equal(t, expectedWoHash, wo.Hash(), "Uncle hashes do not create the expected WorkObject hash")
	} else {
		require.NotEqual(t, expectedUncleHash, wo.Header().UncleHash(), "Uncle hashes do not create the expected root hash")
		require.NotEqual(t, expectedWoHash, wo.Hash(), "Uncle hashes do not create the expected WorkObject hash")
	}
}

func FuzzDataHash(f *testing.F) {
	header, _ := woTestData()
	f.Add(testByte)
	f.Add(header.Data())
	f.Fuzz(func(t *testing.T, b []byte) {
		localHeader, hash := headerTestData()
		if !bytes.Equal(localHeader.extra, b) {
			localHeader.extra = b
			require.NotEqual(t, localHeader.Hash(), hash, "Hash equal for extra \noriginal: %v, modified: %v", header.Data(), b)
		}
	})
}

// Fuzzing newly added fields to WorkObjectHeader to ensure they affect the hash.
// If the auxpow is not updated with the hash, then the WorkObject hash should not change.
func FuzzScryptDiffAndCountHash(f *testing.F) {
	fuzzPowDiffAndCountAfterKawpowFork(f,
		func(woh *WorkObjectHeader) *PowShareDiffAndCount { return woh.scryptDiffAndCount },
		func(woh *WorkObjectHeader, val *PowShareDiffAndCount) { woh.scryptDiffAndCount = val })
}

func FuzzShaDiffAndCountHash(f *testing.F) {
	fuzzPowDiffAndCountAfterKawpowFork(f,
		func(woh *WorkObjectHeader) *PowShareDiffAndCount { return woh.shaDiffAndCount },
		func(woh *WorkObjectHeader, val *PowShareDiffAndCount) { woh.shaDiffAndCount = val })
}

func FuzzShaShareTargetHash(f *testing.F) {
	fuzzBigIntAfterKawpowFork(f,
		func(woh *WorkObjectHeader) *big.Int { return woh.shaShareTarget },
		func(woh *WorkObjectHeader, val *big.Int) { woh.shaShareTarget = val })
}

func FuzzScryptShareTargetHash(f *testing.F) {
	fuzzBigIntAfterKawpowFork(f,
		func(woh *WorkObjectHeader) *big.Int { return woh.scryptShareTarget },
		func(woh *WorkObjectHeader, val *big.Int) { woh.scryptShareTarget = val })
}

func FuzzKawpowDifficultyHash(f *testing.F) {
	fuzzBigIntAfterKawpowFork(f,
		func(woh *WorkObjectHeader) *big.Int { return woh.kawpowDifficulty },
		func(woh *WorkObjectHeader, val *big.Int) { woh.kawpowDifficulty = val })
}

func FuzzAuxPowHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	auxPow := CopyAuxPow(wo.WorkObjectHeader().AuxPow())
	if auxPow == nil {
		return
	}
	f.Add(auxPow.AuxPow2(), auxPow.Signature())
	f.Fuzz(func(t *testing.T, auxPow2 []byte, signature []byte) {
		localWo, hash := woTestDataWithAuxPow()
		localAuxPow := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		if !bytes.Equal(localAuxPow.AuxPow2(), auxPow2) || !bytes.Equal(localAuxPow.Signature(), signature) {
			localAuxPow.SetAuxPow2(auxPow2)
			localAuxPow.SetSignature(signature)
			localWo.WorkObjectHeader().SetAuxPow(localAuxPow)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow changes")
		}
	})
}

func getRavencoinHeader(t *testing.T, ap *AuxPow) *RavencoinBlockHeader {
	require.NotNil(t, ap)
	head := ap.Header()
	require.NotNil(t, head)
	rvh, ok := head.inner.(*RavencoinBlockHeader)
	require.True(t, ok)
	return rvh
}

func FuzzAuxPowPowIDHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := uint32(wo.WorkObjectHeader().AuxPow().PowID())
	f.Add(seed)
	f.Add(seed + 1)
	f.Fuzz(func(t *testing.T, powID uint32) {
		localWo, hash := woTestDataWithAuxPow()
		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		if uint32(aux.PowID()) != powID {
			aux.SetPowID(PowID(powID))
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow.PowID changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow.PowID is the same")
		}
	})
}

func FuzzAuxPowAuxPow2Hash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().AuxPow2()
	f.Add(seed)
	f.Add(testByte)
	f.Fuzz(func(t *testing.T, auxPow2 []byte) {
		localWo, hash := woTestDataWithAuxPow()
		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		if !bytes.Equal(aux.AuxPow2(), auxPow2) {
			aux.SetAuxPow2(auxPow2)
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow.auxPow2 changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow.auxPow2 is the same")
		}
	})
}

func FuzzAuxPowSignatureHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().Signature()
	f.Add(seed)
	f.Add(testByte)
	f.Fuzz(func(t *testing.T, sig []byte) {
		localWo, hash := woTestDataWithAuxPow()
		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		if !bytes.Equal(aux.Signature(), sig) {
			aux.SetSignature(sig)
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow.signature changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow.signature is the same")
		}
	})
}

func FuzzAuxPowMerkleBranchHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	branches := wo.WorkObjectHeader().AuxPow().MerkleBranch()
	seed := []byte{}
	if len(branches) > 0 {
		seed = branches[0]
	}
	f.Add(seed)
	f.Add(testByte)
	f.Fuzz(func(t *testing.T, branch []byte) {
		localWo, hash := woTestDataWithAuxPow()
		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		current := []byte{}
		if len(aux.MerkleBranch()) > 0 {
			current = aux.MerkleBranch()[0]
		}
		if !bytes.Equal(current, branch) {
			aux.SetMerkleBranch([][]byte{branch})
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow.merkleBranch changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow.merkleBranch is the same")
		}
	})
}

func FuzzAuxPowTransactionHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().Transaction()
	f.Add(seed)
	f.Add(testByte)
	f.Fuzz(func(t *testing.T, tx []byte) {
		localWo, hash := woTestDataWithAuxPow()
		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		if !bytes.Equal(aux.Transaction(), tx) {
			aux.SetTransaction(tx)
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow.transaction changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow.transaction is the same")
		}
	})
}

func FuzzAuxPowHeaderVersionHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().Header().Version()
	f.Add(seed)
	f.Add(int32(100))
	f.Fuzz(func(t *testing.T, version int32) {
		localWo, hash := woTestDataWithAuxPow()
		originalVersion := localWo.WorkObjectHeader().AuxPow().Header().Version()

		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		header := getRavencoinHeader(t, aux)
		header.Version = version // This is now safe as it's a fresh header copy
		aux.SetHeader(NewAuxPowHeader(header))
		localWo.WorkObjectHeader().SetAuxPow(aux)

		if originalVersion != version {
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow header version changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow header version is the same")
		}
	})
}

func FuzzAuxPowHeaderPrevBlockHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	prevBlock := wo.WorkObjectHeader().AuxPow().Header().PrevBlock()
	seed := prevBlock[:]
	f.Add(seed)
	f.Add(testByte)
	f.Fuzz(func(t *testing.T, prev []byte) {
		localWo, hash := woTestDataWithAuxPow()
		originalPrevBlock := localWo.WorkObjectHeader().AuxPow().Header().PrevBlock()

		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		header := getRavencoinHeader(t, aux)
		if !bytes.Equal(originalPrevBlock[:], prev) {
			header.HashPrevBlock = common.BytesToHash(prev)
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow header prev block changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow header prev block is the same")
		}
	})
}

func FuzzAuxPowHeaderMerkleRootHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	merkleRoot := wo.WorkObjectHeader().AuxPow().Header().MerkleRoot()
	seed := merkleRoot[:]
	f.Add(seed)
	f.Add(testByte)
	f.Fuzz(func(t *testing.T, root []byte) {
		localWo, hash := woTestDataWithAuxPow()
		originalMerkleRoot := localWo.WorkObjectHeader().AuxPow().Header().MerkleRoot()

		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		header := getRavencoinHeader(t, aux)
		if !bytes.Equal(originalMerkleRoot[:], root) {
			header.HashMerkleRoot = common.BytesToHash(root)
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow header merkle root changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow header merkle root is the same")
		}
	})
}

func FuzzAuxPowHeaderTimestampHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().Header().Timestamp()
	f.Add(seed)
	f.Add(uint32(100))
	f.Add(uint32(101))
	f.Fuzz(func(t *testing.T, ts uint32) {
		localWo, hash := woTestDataWithAuxPow()
		originalTimestamp := localWo.WorkObjectHeader().AuxPow().Header().Timestamp()

		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		header := getRavencoinHeader(t, aux)
		if originalTimestamp != ts {
			header.Time = ts
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow header timestamp changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow header timestamp is the same")
		}
	})
}

func FuzzAuxPowHeaderBitsHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().Header().Bits()
	f.Add(seed)
	f.Add(uint32(100))
	f.Add(uint32(101))
	f.Fuzz(func(t *testing.T, bits uint32) {
		localWo, hash := woTestDataWithAuxPow()
		originalBits := localWo.WorkObjectHeader().AuxPow().Header().Bits()

		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		header := getRavencoinHeader(t, aux)
		if originalBits != bits {
			header.Bits = bits
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow header bits changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow header bits is the same")
		}
	})
}

func FuzzAuxPowHeaderHeightHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().Header().Height()
	f.Add(seed)
	f.Add(uint32(100))
	f.Add(uint32(101))
	f.Fuzz(func(t *testing.T, height uint32) {
		localWo, hash := woTestDataWithAuxPow()
		originalHeight := localWo.WorkObjectHeader().AuxPow().Header().Height()

		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		header := getRavencoinHeader(t, aux)
		if originalHeight != height {
			header.Height = height
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow header height changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow header height is the same")
		}
	})
}

func FuzzAuxPowHeaderNonce64Hash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().Header().Nonce64()
	f.Add(seed)
	f.Add(uint64(0))
	f.Add(uint64(1))
	f.Fuzz(func(t *testing.T, nonce uint64) {
		localWo, hash := woTestDataWithAuxPow()
		originalNonce := localWo.WorkObjectHeader().AuxPow().Header().Nonce64()

		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		header := getRavencoinHeader(t, aux)
		if originalNonce != nonce {
			header.Nonce64 = nonce
			aux.SetHeader(NewAuxPowHeader(header))
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow header nonce64 changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow header nonce64 is the same")
		}
	})
}

func FuzzAuxPowHeaderMixHash(f *testing.F) {
	wo, _ := woTestDataWithAuxPow()
	seed := wo.WorkObjectHeader().AuxPow().Header().MixHash().Bytes()
	f.Add(seed)
	f.Add(testByte)
	f.Fuzz(func(t *testing.T, mix []byte) {
		localWo, hash := woTestDataWithAuxPow()
		originalMixHash := localWo.WorkObjectHeader().AuxPow().Header().MixHash()

		aux := CopyAuxPow(localWo.WorkObjectHeader().AuxPow())
		header := getRavencoinHeader(t, aux)
		if !bytes.Equal(originalMixHash.Bytes(), mix) {
			header.MixHash = common.BytesToHash(mix)
			localWo.WorkObjectHeader().SetAuxPow(aux)
			require.NotEqual(t, localWo.Hash(), hash, "Hash should change when auxpow header mixhash changes")
		} else {
			require.Equal(t, localWo.Hash(), hash, "Hash should not change when auxpow header mixhash is the same")
		}
	})
}

func fuzzHash(f *testing.F, getField func(*WorkObjectHeader) common.Hash, setField func(*WorkObjectHeader, common.Hash)) {
	wo, _ := woTestData()
	f.Add(testByte)
	f.Add(getField(wo.woHeader).Bytes())
	f.Fuzz(func(t *testing.T, b []byte) {
		localWo, hash := woTestData()
		sc := common.BytesToHash(b)
		if getField(localWo.woHeader) != sc {
			setField(localWo.woHeader, sc)
			require.NotEqual(t, localWo.Hash(), hash, "Hash collision\noriginal: %v, modified: %v", getField(wo.woHeader).Bytes(), b)
		}
	})
}

func fuzzUint64Field(f *testing.F, getVal func(*WorkObjectHeader) uint64, setVal func(*WorkObjectHeader, uint64)) {
	wo, _ := woTestData()
	f.Add(testUInt64)
	f.Add(getVal(wo.woHeader))
	f.Fuzz(func(t *testing.T, i uint64) {
		localWo, hash := woTestData()
		if getVal(localWo.woHeader) != i {
			setVal(localWo.woHeader, i)
			require.NotEqual(t, localWo.Hash(), hash, "Hash collision\noriginal: %v, modified: %v", getVal(wo.woHeader), i)
		}
	})
}

func fuzzBigInt(f *testing.F, getVal func(*WorkObjectHeader) *big.Int, setVal func(*WorkObjectHeader, *big.Int)) {
	wo, _ := woTestData()
	f.Add(testInt64)
	f.Add(getVal(wo.woHeader).Int64())
	f.Fuzz(func(t *testing.T, i int64) {
		localWo, hash := woTestData()
		bi := big.NewInt(i)
		if getVal(localWo.woHeader).Cmp(bi) != 0 {
			setVal(localWo.woHeader, bi)
			require.NotEqual(t, localWo.Hash(), hash, "Hash collision\noriginal: %v, modified: %v", getVal(wo.woHeader), bi)
		}
	})
}

// testAuxPow creates a test AuxPow with default values
func testAuxPow() *AuxPow {
	ravencoinHeader := &RavencoinBlockHeader{
		Version:        4,
		HashPrevBlock:  EmptyRootHash,
		HashMerkleRoot: EmptyRootHash,
		Time:           34545,
		Bits:           0x1d00ffff,
		Nonce64:        367899,
		Height:         298899,
		MixHash:        EmptyRootHash,
	}
	header := NewAuxPowHeader(ravencoinHeader)
	coinbaseOut := []byte{0x76, 0xa9, 0x14, 0x89, 0xab, 0xcd, 0xef, 0x88, 0xac}
	coinbaseTx := NewAuxPowCoinbaseTx(Kawpow, 100, coinbaseOut, EmptyRootHash, 123)
	return NewAuxPow(
		Kawpow,
		header,
		[]byte{},
		[]byte{0x03, 0x04},
		[][]byte{},
		coinbaseTx,
	)
}

func fuzzBigIntAfterKawpowFork(f *testing.F, getVal func(*WorkObjectHeader) *big.Int, setVal func(*WorkObjectHeader, *big.Int)) {
	wo, _ := woTestDataWithAuxPow()
	f.Add(testInt64)
	f.Add(getVal(wo.woHeader).Int64())
	f.Fuzz(func(t *testing.T, i int64) {
		localWo, hash := woTestDataWithAuxPow()
		bi := big.NewInt(i)
		if getVal(localWo.woHeader).Cmp(bi) != 0 {
			setVal(localWo.woHeader, bi)
			require.Equal(t, localWo.Hash(), hash, "Hash shouldnt change without changing the auxpow\noriginal: %v, modified: %v", getVal(wo.woHeader), bi)
		}
	})
}

func fuzzPowDiffAndCountAfterKawpowFork(f *testing.F, getVal func(*WorkObjectHeader) *PowShareDiffAndCount, setVal func(*WorkObjectHeader, *PowShareDiffAndCount)) {
	wo, _ := woTestDataWithAuxPow()
	seed := powDiffAndCountTestData()
	f.Add(seed.Difficulty().Int64(), seed.Count().Int64())
	current := getVal(wo.woHeader)
	if current != nil && current.Difficulty() != nil && current.Count() != nil {
		f.Add(current.Difficulty().Int64(), current.Count().Int64())
	}
	f.Fuzz(func(t *testing.T, diff int64, count int64) {
		localWo, hash := woTestDataWithAuxPow()
		powDiff := NewPowShareDiffAndCount(big.NewInt(diff), big.NewInt(count), big.NewInt(count))
		if !getVal(localWo.woHeader).Cmp(powDiff) {
			setVal(localWo.woHeader, powDiff)
			require.Equal(t, localWo.Hash(), hash, "Hash shouldnt change without changing the auxpow\noriginal: %v, modified: %v", getVal(wo.woHeader), powDiff)
		}
	})
}

func TestSealHashChange(t *testing.T) {
	wo, _ := woTestDataWithAuxPow()

	// Changin the primary coinbase or setting it to nil should change the
	// sealhash

	woCopy := CopyWorkObject(wo)
	woCopy.WorkObjectHeader().SetPrimaryCoinbase(common.BytesToAddress([]byte{0x0, 0x0, 0x1, 0x2}, common.Location{0, 0}))
	require.NotEqual(t, woCopy.SealHash(), wo.SealHash(), "Seal hash didn't change when auxpow coinbase tx set to nil")

	woCopy2 := CopyWorkObject(wo)
	woCopy2.WorkObjectHeader().SetPrimaryCoinbase(common.BytesToAddress([]byte{0x0, 0x0, 0x1, 0x3}, common.Location{0, 0}))
	require.NotEqual(t, woCopy2.SealHash(), wo.SealHash(), "Seal hash didn't change when auxpow coinbase tx changed")

	_, intermediateWo1 := wo.WorkObjectHeader().SealHashWithIntermediateHash()
	_, intermediateWo2 := woCopy.WorkObjectHeader().SealHashWithIntermediateHash()

	require.Equal(t, intermediateWo1, intermediateWo2, "Intermediate seal hash changed when auxpow coinbase tx changed")
}

func (wh *WorkObjectHeader) SealHashWithIntermediateHash() (final, intermediate common.Hash) {
	protoSealData := wh.SealEncode()
	primaryCoinbase := wh.PrimaryCoinbase().Bytes()
	// After the kawpow activation update the seal hash to be
	// without the primary coinbase and then hash the coinbase
	// with the sealhash
	if wh.KawpowActivationHappened() {
		protoSealData.PrimaryCoinbase = nil
	}
	data, err := proto.Marshal(protoSealData)
	if err != nil {
		log.Global.Error("Failed to marshal seal data ", "err", err)
	}

	sum := blake3.Sum256(data[:])

	intermediate.SetBytes(sum[:])

	if wh.KawpowActivationHappened() {
		// Encode the primary coinbase separately
		sum = blake3.Sum256(append(sum[:], primaryCoinbase...))
	}

	final.SetBytes(sum[:])

	return final, intermediate
}
